from django.shortcuts import  render,redirect
from .models import Available_Coruses
from .models import Admisson_Form
from .models import Customer
from .models import LoginForm
from django.contrib.messages.api import success
from django.contrib import messages


def home(request):
    return render(request,"home.html")

def register(request):
    student=Customer(request.POST)
    if request.method=='POST':
        name=request.POST["name"]
        email=request.POST["email"]
        password=request.POST["password"]

        check=Customer.objects.filter(email=email).exists()
        if check:
            messages.success(request,'User Already Exists')
            return redirect('/register')
        
        else:
            student=Customer.objects.create(name=name,email=email,password=password)
            student.save()
            messages.success(request,'Register Succesfully')
   
    return render(request,'register.html',{'student':student})

def login_page(request):
    if request.method=='POST':
        name=request.POST["name"]
        password=request.POST["password"]
        form=LoginForm.objects.create(name=name,password=password)
        form.save() 
    return render(request,"login.html")

def admissonform(request):
    if request.method=='POST':
        name=request.POST["name"]
        email=request.POST["email"]
        mobilenumber=request.POST["mobilenumber"]
        password=request.POST["password"]
        select_course=request.POST["select_course"]
        dob=request.POST["dob"]
        state=request.POST["state"]
        city=request.POST["city"]
        pincode=request.POST["pincode"]
        message=request.POST["message"]
        
        admisson=Admisson_Form.objects.create(name=name,email=email,mobilenumber=mobilenumber,password=password,select_course=select_course,dob=dob,state=state,city=city,pincode=pincode,message=message)
        admisson.save()
       
    return render(request,"admissonform.html")
       
    


      

def coruses(request):
    data=Available_Coruses.objects.all()
    return render(request,'coruses.html',{'data':data})

def corusesviews(request,id):
    details=Available_Coruses.objects.get(id=id)
    return render(request,'corusesviews.html',{'details':details})
# def form(request):
#     admission=Admisson_Form.objects.all()
#     return render(request,'corusesviews.html',{'admission':admission})


    
    
        
        
    
     
   
    
 
    

