from django.db import models
import datetime
import os

def getFilName(request,filename):
    now_time=datetime.datetime.now().strftime("%Y%m%d%H:%M:%S")
    new_filename="%s%s"%(now_time,filename)
    return os.path.join('uploads/',new_filename)


class Available_Coruses(models.Model):
 Coruses_name=models.CharField(max_length=50,null=False,blank=False)
 Coruses_image=models.ImageField(upload_to="images/",null=True,blank=True)
 Coruses_Duration=models.TextField(max_length=10,null=False,blank=False)
 Coruses_Employment_opportunities=models.TextField(max_length=100,null=False,blank=False)
 Coruses_fees=models.FloatField(null=False,blank=False)
 Coruses_offer_fees=models.FloatField(null=False,blank=False)
 status=models.BooleanField(default=False,help_text="0-show,1-Hidden")
 Coruses_trending=models.BooleanField(default=False,help_text="0-default,1-Trending")
 Coruses_description=models.TextField(max_length=3000,null=False,blank=False)
 Coruses_at=models.DateTimeField(auto_now_add=True)

def __str__(self) :
    return self.name
   
class Admisson_Form(models.Model):
    GENDER_CHOICES=[
        ('Male','Male'),
        ('Female','Female'),
    ]
    COURSE_CHOICES=[
        ('Java','Java'),
        ('Java_Script','Java_Script'),
        ('Python','Python'),
        ('Django','Django'),
        ('Html','Html'),
        ('Css','Css'),
        ('Bootstrap','Bootstrap'),
        ('Mysql','Mysql'),
        ('Mongo_Dp','Mongo_Dp'),
        ('Node_Js','Node_Js'),
        ('Angular','Angular'),
        ('React_Js','React_Js'),  
    ]
    name=models.CharField(max_length=150,null=False,blank=False)
    email=models.EmailField(max_length=50,null=False,blank=False)
    mobilenumber=models.IntegerField(null=True)
    password=models.CharField(max_length=100,null=True)
    gender=models.CharField(max_length=20,null=True,choices=GENDER_CHOICES)
    select_coruse=models.CharField(max_length=20,null=True,choices=COURSE_CHOICES)
    dob=models.DateField()
    state=models.CharField(max_length=50,null=False,blank=False)
    city=models.CharField(max_length=50,null=False,blank=False)
    pincode=models.IntegerField(null=False,blank=False)
    message=models.CharField(max_length=50,null=False,blank=False)
    
def __str__(self):
    return self.name


class Customer(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField()
    password=models.CharField(max_length=100,null=True)

class LoginForm(models.Model):
    name=models.CharField(max_length=100)
    password=models.CharField(max_length=100,null=True)