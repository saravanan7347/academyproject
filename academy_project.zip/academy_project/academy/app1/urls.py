from django.urls import path
from . import views


urlpatterns=[
    path('home/',views.home,name="home"),
    path('register/',views.register,name="register"),
    path('login/',views.login_page,name="login"),
    # path('logout/',views.logout_page,name="logout"),
    path('coruses/',views.coruses,name="coruses"),
    path('coruses/corusesviews/<int:id>',views.corusesviews,name="corusesviews"),
    path('admissonform',views.admissonform,name="admissonform"),
    
]