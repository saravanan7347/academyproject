from django.contrib import admin
from .models import Available_Coruses
from .models import Admisson_Form
from .models import Customer
from .models import LoginForm



admin.site.register(Available_Coruses)
admin.site.register(Admisson_Form)
admin.site.register(Customer)
admin.site.register(LoginForm)


